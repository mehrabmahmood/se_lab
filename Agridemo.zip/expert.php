<?php require 'config.php'; require_login(); if($_SESSION['user_type'] !== 'expert') { header('Location: login.php'); exit(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expert Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/peerjs@1.3.1/dist/peerjs.min.js"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto p-6">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-3xl font-bold text-green-700">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?> (Expert)</h1>
            <a href="logout.php" class="bg-red-600 text-white px-5 py-2 rounded hover:bg-red-700">Logout</a>
        </div>

        <div class="bg-white p-6 rounded-lg shadow mb-8">
            <h2 class="text-2xl font-bold mb-4">Pending Farmer Issues</h2>
            <div id="issuesList" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Issues will be loaded via JS + WebSocket later -->
                <p class="text-gray-500">No issues yet. Waiting for farmers...</p>
            </div>
        </div>

        <!-- Chat & Video -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-bold mb-4">Chat with Farmer</h2>
                <div id="chatMessages" class="h-64 overflow-y-auto border p-4 mb-4 bg-gray-50"></div>
                 <!-- <div class="mb-4">
                     <img src="Farmer.jpg" alt="" style="width:612px;height:300px;">
                 </div> -->
                <div class="flex">
                    <input type="text" id="chatInput" placeholder="Type solution..." class="flex-1 p-3 border rounded-l-lg">
                    <button onclick="sendChatMessage()" class="bg-green-600 text-white px-6 rounded-r-lg hover:bg-green-700">Send</button>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-bold mb-4">Video Calls</h2>
                <div id="callNotification" class="text-lg font-semibold text-purple-700 mb-4"></div>
                <button id="acceptButton" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 hidden">Accept Call</button>
                <div class="grid grid-cols-2 gap-4 mt-4">
                    <video id="localVideo" autoplay playsinline muted class="w-full rounded border"></video>
                    <video id="remoteVideo" autoplay playsinline class="w-full rounded border"></video>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Real-time features will be added with Ratchet WebSocket
        alert('Real-time chat & video calling coming in next phase with WebSocket server!');
    </script>
</body>
</html>