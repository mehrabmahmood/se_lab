<?php require 'config.php'; require_login(); if($_SESSION['user_type'] !== 'farmer') { header('Location: login.php'); exit(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmer Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/peerjs@1.3.1/dist/peerjs.min.js"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto p-6">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-3xl font-bold text-green-700">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?> (Farmer)</h1>
            <a href="logout.php" class="bg-red-600 text-white px-5 py-2 rounded hover:bg-red-700">Logout</a>
        </div>

        <!-- Image Upload -->
        <div class="bg-white p-6 rounded-lg shadow mb-8">
            <h2 class="text-2xl font-bold mb-4">Report Crop Issue</h2>
            <form id="uploadForm" enctype="multipart/form-data">
                <input type="file" id="image" name="image" accept="image/*" required class="mb-4 block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer">
                <textarea id="description" name="description" rows="4" placeholder="Describe the problem..." required class="w-full p-3 border rounded-lg mb-4"></textarea>
                <button type="button" onclick="uploadIssue()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">Submit Issue</button>
            </form>
        </div>

        <!-- Chat & Video Section -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-bold mb-4">Chat with Expert</h2>
                <div id="chatMessages" class="h-64 overflow-y-auto border p-4 mb-4 bg-gray-50"></div>
                 <!-- <div class="mb-4">
                    <img src="Farmer.jpg" alt="" style="width:612px;height:300px;">
                 </div> -->
                <div class="flex">
                    <input type="text" id="chatInput" placeholder="Type message..." class="flex-1 p-3 border rounded-l-lg">
                    <button onclick="sendChatMessage()" class="bg-green-600 text-white px-6 rounded-r-lg hover:bg-green-700">Send</button>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-bold mb-4">Video Consultation</h2>
                <button onclick="startCall()" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 mb-4">Call Expert Now</button>
                <div class="grid grid-cols-2 gap-4">
                    <video id="localVideo" autoplay playsinline muted class="w-full rounded border"></video>
                    <video id="remoteVideo" autoplay playsinline class="w-full rounded border"></video>
                </div>
            </div>
        </div>
    </div>

    <script>
        // WebSocket & PeerJS code will go here later (after Ratchet setup)
        function uploadIssue() {
            const formData = new FormData();
            formData.append('image', document.getElementById('image').files[0]);
            formData.append('description', document.getElementById('description').value);
            formData.append('action', 'upload_issue');

            fetch('upload.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) alert('Issue submitted! Expert will respond soon.');
                    else alert('Upload failed.');
                });
        }

        function sendChatMessage() {
            // Will connect to WebSocket later
            alert('Chat system coming soon with WebSocket!');
        }

        function startCall() {
            alert('Video calling system will work after WebSocket + PeerJS setup!');
        }
    </script>
</body>
</html>