<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

$user = require_farmer_only();
$uid = (int)$user['id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

if (!csrf_verify($_POST['csrf_token'] ?? '')) {
    flash_set('error', 'Invalid request (CSRF).');
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

$message_id = (int)($_POST['message_id'] ?? 0);
$other_id = (int)($_POST['user_id'] ?? 0);

if ($message_id <= 0 || $other_id <= 0) {
    flash_set('error', 'Invalid message.');
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

// Security: ensure the other user is a farmer too
$other = user_find_by_id($other_id);
if (!$other || (string)$other['role'] !== 'farmer') {
    flash_set('error', 'Invalid chat user.');
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

message_delete_for_user($uid, $message_id);
flash_set('success', 'Message deleted for you.');
redirect_path(APP_BASE_URL . '/messages/thread.php?user_id=' . $other_id);
