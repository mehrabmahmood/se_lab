<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

// Messaging is Farmers-only
$user = require_farmer_only();
$uid = (int)$user['id'];

$threads = messages_thread_list($uid);

$errors = [];
$email = '';

// Start a new chat by email (farmer-to-farmer only)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request (CSRF).';
    } else {
        $email = trim((string)($_POST['email'] ?? ''));
        if (!validate_email_address($email)) {
            $errors[] = 'Enter a valid email.';
        } else {
            $other = user_find_by_email($email);
            if (!$other) {
                $errors[] = 'No user found with that email.';
            } elseif ((int)$other['id'] === $uid) {
                $errors[] = 'You cannot message yourself.';
            } elseif ((string)$other['role'] !== 'farmer') {
                $errors[] = 'Messaging is Farmers-only. You can message farmers only.';
            } elseif ((int)$other['is_verified'] !== 1) {
                $errors[] = 'That user has not verified their email yet.';
            } else {
                // If the other user is banned, do not allow starting a chat
                [$banned, ] = user_is_banned($other);
                if ($banned) {
                    $errors[] = 'That user is currently banned.';
                } elseif (is_blocked_any_direction($uid, (int)$other['id'])) {
                    $errors[] = 'Messaging is disabled because one of you has blocked the other.';
                } else {
                    redirect_path(APP_BASE_URL . '/messages/thread.php?user_id=' . (int)$other['id']);
                }
            }
        }
    }
}

$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h(APP_NAME) ?> - Messages</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-50">
  <div class="max-w-4xl mx-auto p-6">
    <div class="flex items-center justify-between flex-wrap gap-3">
      <div>
        <h1 class="text-2xl font-bold">Messages</h1>
        <p class="text-sm text-gray-600">Private chat (Farmers only). Messages are saved. You can delete messages from your side.</p>
      </div>
      <div class="flex gap-2 flex-wrap">
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/blog/index.php">Community Blog</a>
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/home.php">Home</a>
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/logout.php">Logout</a>
      </div>
    </div>

    <?php if ($flash): ?>
      <div class="mt-4 p-3 rounded <?= $flash['type']==='error' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700' ?>">
        <?= h((string)$flash['message']) ?>
      </div>
    <?php endif; ?>

    <?php if ($errors): ?>
      <div class="mt-4 p-3 rounded bg-red-50 text-red-700">
        <ul class="list-disc pl-5 space-y-1">
          <?php foreach ($errors as $e): ?><li><?= h((string)$e) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="post" class="mt-6 bg-white rounded-2xl shadow p-6 flex flex-col gap-3">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <label class="text-sm font-medium">Start a new chat (enter farmer email)</label>
      <div class="flex gap-2 flex-wrap">
        <input name="email" type="email" value="<?= h($email) ?>" placeholder="farmer@example.com" class="flex-1 rounded-lg border p-2" required>
        <button class="px-4 py-2 rounded-lg bg-blue-600 text-white font-semibold">Open chat</button>
      </div>
      <p class="text-xs text-gray-500">If either user blocks the other, messaging is disabled.</p>
    </form>

    <div class="mt-6">
      <h2 class="text-lg font-bold">Your conversations</h2>

      <div class="mt-3 space-y-3">
        <?php if (!$threads): ?>
          <div class="bg-white rounded-2xl shadow p-6 text-gray-600">No messages yet.</div>
        <?php endif; ?>

        <?php foreach ($threads as $t): ?>
          <div class="bg-white rounded-2xl shadow p-5 flex items-start justify-between gap-3">
            <div>
              <a class="font-semibold hover:underline" href="<?= h(APP_BASE_URL) ?>/messages/thread.php?user_id=<?= (int)$t['other_id'] ?>">
                <?= h((string)$t['other_name']) ?>
              </a>
              <div class="text-xs text-gray-500 mt-1">
                Last: <?= h((string)$t['last_time']) ?> (UTC)
              </div>
            </div>
            <div class="flex gap-3 text-xs">
              <a class="text-blue-700 hover:underline" href="<?= h(APP_BASE_URL) ?>/messages/thread.php?user_id=<?= (int)$t['other_id'] ?>">Open</a>
              <a class="text-red-600 hover:underline" href="<?= h(APP_BASE_URL) ?>/blog/block.php?user_id=<?= (int)$t['other_id'] ?>">Block</a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</body>
</html>
