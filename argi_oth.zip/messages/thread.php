<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

// Farmers-only messaging
$user = require_farmer_only();
$uid = (int)$user['id'];

$other_id = (int)($_GET['user_id'] ?? 0);
if ($other_id <= 0 || $other_id === $uid) {
    flash_set('error', 'Invalid chat user.');
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

$other = user_find_by_id($other_id);
if (!$other) {
    flash_set('error', 'User not found.');
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

// Farmer-to-farmer only
if ((string)$other['role'] !== 'farmer') {
    flash_set('error', 'Messaging is Farmers-only.');
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

if ((int)$other['is_verified'] !== 1) {
    flash_set('error', 'That user has not verified email yet.');
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

[$other_banned, ] = user_is_banned($other);
if ($other_banned) {
    flash_set('error', 'That user is currently banned.');
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

if (is_blocked_any_direction($uid, $other_id)) {
    flash_set('error', 'Chat is disabled because one of you blocked the other.');
    redirect_path(APP_BASE_URL . '/messages/inbox.php');
}

$errors = [];
$body = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request (CSRF).';
    } else {
        $body = trim((string)($_POST['body'] ?? ''));
        if ($body === '' || mb_strlen($body) < 1) {
            $errors[] = 'Write a message.';
        } elseif (mb_strlen($body) > 2000) {
            $errors[] = 'Message is too long (max 2000 characters).';
        }

        // Re-check block (race-safe)
        if (!$errors && is_blocked_any_direction($uid, $other_id)) {
            $errors[] = 'Chat is disabled because one of you blocked the other.';
        }

        if (!$errors) {
            message_send($uid, $other_id, $body);
            $body = '';
            redirect_path(APP_BASE_URL . '/messages/thread.php?user_id=' . $other_id);
        }
    }
}

$thread = messages_get_thread($uid, $other_id, 300);
$flash = flash_get();
$csrf = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h(APP_NAME) ?> - Chat with <?= h((string)$other['full_name']) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-50">
  <div class="max-w-4xl mx-auto p-6">
    <div class="flex items-center justify-between flex-wrap gap-3">
      <div>
        <a class="text-sm text-gray-700 hover:underline" href="<?= h(APP_BASE_URL) ?>/messages/inbox.php">&larr; Back to inbox</a>
        <h1 class="text-2xl font-bold mt-2">Chat with <?= h((string)$other['full_name']) ?></h1>
        <p class="text-sm text-gray-600">Farmers-only private messages. Saved in database. You can delete a message from your side.</p>
      </div>
      <div class="flex gap-2 flex-wrap">
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/blog/index.php">Community Blog</a>
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/home.php">Home</a>
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/logout.php">Logout</a>
      </div>
    </div>

    <?php if ($flash): ?>
      <div class="mt-4 p-3 rounded <?= $flash['type']==='error' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700' ?>">
        <?= h((string)$flash['message']) ?>
      </div>
    <?php endif; ?>

    <?php if ($errors): ?>
      <div class="mt-4 p-3 rounded bg-red-50 text-red-700">
        <ul class="list-disc pl-5 space-y-1">
          <?php foreach ($errors as $e): ?><li><?= h((string)$e) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="mt-6 bg-white rounded-2xl shadow p-4">
      <div class="space-y-3">
        <?php if (!$thread): ?>
          <div class="text-gray-600">No messages yet. Say hi 👋</div>
        <?php endif; ?>

        <?php foreach ($thread as $m): ?>
          <?php $mine = ((int)$m['sender_id'] === $uid); ?>
          <div class="flex <?= $mine ? 'justify-end' : 'justify-start' ?>">
            <div class="max-w-[85%] rounded-2xl px-4 py-3 <?= $mine ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-900' ?>">
              <div class="text-xs opacity-80 mb-1">
                <?= $mine ? 'You' : h((string)$m['sender_name']) ?> • <?= h((string)$m['created_at']) ?> (UTC)
              </div>
              <div class="text-sm whitespace-pre-wrap break-words"><?= h((string)$m['body']) ?></div>

              <div class="mt-2 text-xs flex justify-end">
                <form method="post" action="<?= h(APP_BASE_URL) ?>/messages/delete.php" onsubmit="return confirm('Delete this message for you?');">
                  <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
                  <input type="hidden" name="message_id" value="<?= (int)$m['id'] ?>">
                  <input type="hidden" name="user_id" value="<?= (int)$other_id ?>">
                  <button class="underline">Delete</button>
                </form>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <form method="post" class="mt-4 bg-white rounded-2xl shadow p-4">
      <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
      <label class="block text-sm font-medium">Write a message</label>
      <textarea name="body" rows="3" class="mt-1 w-full rounded-lg border p-2" placeholder="Type your message..." required><?= h($body) ?></textarea>
      <div class="mt-3 flex items-center justify-between gap-2 flex-wrap">
        <p class="text-xs text-gray-500">Tip: Keep it respectful. Malicious content can be reported in the Blog comments.</p>
        <button class="px-4 py-2 rounded-lg bg-blue-600 text-white font-semibold">Send</button>
      </div>
    </form>

    <div class="mt-4">
      <a class="text-red-600 hover:underline text-sm" href="<?= h(APP_BASE_URL) ?>/blog/block.php?user_id=<?= (int)$other_id ?>" onclick="return confirm('Block this user? This will also disable messaging.');">Block/Unblock user</a>
    </div>
  </div>
</body>
</html>
