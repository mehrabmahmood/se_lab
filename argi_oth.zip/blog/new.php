<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

$user = require_farmer_access();
if (is_admin()) {
    flash_set('error', 'Admin cannot create posts here.');
    redirect_path(APP_BASE_URL . '/blog/index.php');
}

$title = '';
$body = '';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!csrf_verify($token)) {
        $errors[] = 'Invalid request (CSRF). Please try again.';
    } else {
        $title = trim((string)($_POST['title'] ?? ''));
        $body = trim((string)($_POST['body'] ?? ''));

        if ($title === '' || strlen($title) < 5) $errors[] = 'Title must be at least 5 characters.';
        if ($body === '' || strlen($body) < 10) $errors[] = 'Body must be at least 10 characters.';

        if (!$errors) {
            $paths = [];
            if (!empty($_FILES['images'])) {
                $paths = upload_images($_FILES['images'], 'posts');
            }

            $post_id = post_create((int)$user['id'], $title, $body, $paths);
            flash_set('success', 'Post created!');
            redirect_path(APP_BASE_URL . '/blog/view.php?id=' . $post_id);
        }
    }
}

$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h(APP_NAME) ?> - New Post</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-50">
  <div class="max-w-3xl mx-auto p-6">
    <div class="flex items-center justify-between">
      <h1 class="text-2xl font-bold">New Post</h1>
      <a class="text-sm text-gray-700 hover:underline" href="<?= h(APP_BASE_URL) ?>/blog/index.php">Back</a>
    </div>

    <?php if ($flash): ?>
      <div class="mt-4 p-3 rounded <?= $flash['type']==='error' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700' ?>">
        <?= h((string)$flash['message']) ?>
      </div>
    <?php endif; ?>

    <?php if ($errors): ?>
      <div class="mt-4 p-3 rounded bg-red-50 text-red-700">
        <ul class="list-disc pl-5 space-y-1">
          <?php foreach ($errors as $e): ?><li><?= h((string)$e) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="mt-6 bg-white rounded-2xl shadow p-6 space-y-4">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">

      <div>
        <label class="block text-sm font-medium">Title</label>
        <input name="title" value="<?= h($title) ?>" required class="mt-1 w-full rounded-lg border p-2">
      </div>

      <div>
        <label class="block text-sm font-medium">Question / Details</label>
        <textarea name="body" rows="8" required class="mt-1 w-full rounded-lg border p-2"><?= h($body) ?></textarea>
      </div>

      <div>
        <label class="block text-sm font-medium">Upload images (optional)</label>
        <input name="images[]" type="file" multiple accept="image/jpeg,image/png,image/webp" class="mt-1 w-full">
        <p class="text-xs text-gray-500 mt-1">Max <?= (int)UPLOAD_MAX_FILES ?> files, max <?= (int)(UPLOAD_MAX_BYTES/1024/1024) ?>MB each.</p>
      </div>

      <button class="w-full bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg py-2">Post</button>
    </form>
  </div>
</body>
</html>
