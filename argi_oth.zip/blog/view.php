<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

$user = require_farmer_access();
$uid = is_admin() ? 0 : (int)$user['id'];
$post_id = (int)($_GET['id'] ?? 0);
if ($post_id <= 0) {
    flash_set('error', 'Post not found.');
    redirect_path(APP_BASE_URL . '/blog/index.php');
}

$post = is_admin() ? null : post_get($uid, $post_id);
if (is_admin()) {
    $stmt = db()->prepare("SELECT p.*, u.full_name, u.role FROM posts p JOIN users u ON u.id=p.user_id WHERE p.id=? AND p.is_deleted=0 LIMIT 1");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch() ?: null;
}

if (!$post) {
    flash_set('error', 'Post not found (maybe blocked).');
    redirect_path(APP_BASE_URL . '/blog/index.php');
}

$images = post_images($post_id);

// comments
$comments = is_admin()
    ? (function() use ($post_id) {
        $stmt = db()->prepare("SELECT c.*, u.full_name, u.role FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? AND c.is_deleted=0 ORDER BY c.created_at ASC");
        $stmt->execute([$post_id]);
        return $stmt->fetchAll();
      })()
    : comments_for_post($uid, $post_id);

// build tree
$byParent = [];
foreach ($comments as $c) {
    $pid = $c['parent_id'] ? (int)$c['parent_id'] : 0;
    $byParent[$pid][] = $c;
}

function render_comments(array $byParent, int $parent, array $viewer, int $depth = 0): void {
    if (empty($byParent[$parent])) return;
    foreach ($byParent[$parent] as $c) {
        $cid = (int)$c['id'];
        $authorId = (int)$c['user_id'];
        $pad = min($depth * 16, 64);
        echo '<div class="mt-4" style="margin-left:' . $pad . 'px">';
        echo '<div class="bg-white rounded-xl shadow p-4" id="c' . $cid . '">';
        echo '<div class="flex items-start justify-between gap-3">';
        echo '<div class="text-sm">';
        echo '<div class="font-semibold">' . h((string)$c['full_name']) . ' <span class="ml-2 text-xs px-2 py-0.5 rounded-full bg-gray-100">' . h((string)$c['role']) . '</span></div>';
        echo '<div class="text-xs text-gray-500">' . h((string)$c['created_at']) . ' (UTC)</div>';
        echo '</div>';

        if (!is_admin()) {
            echo '<div class="flex gap-3 text-xs">';
            echo '<a class="text-green-700 hover:underline" href="' . h(APP_BASE_URL) . '/blog/view.php?id=' . (int)$c['post_id'] . '&reply_to=' . $cid . '#commentform">Reply</a>';
            echo '<a class="text-blue-700 hover:underline" href="' . h(APP_BASE_URL) . '/messages/thread.php?user_id=' . $authorId . '">Message</a>';
            if ($authorId !== (int)$viewer['id']) {
                echo '<a class="text-red-600 hover:underline" href="' . h(APP_BASE_URL) . '/blog/block.php?user_id=' . $authorId . '">Block</a>';
                echo '<a class="text-orange-600 hover:underline" href="' . h(APP_BASE_URL) . '/blog/report.php?type=comment&id=' . $cid . '">Report</a>';
            }
            echo '</div>';
        } else {
            echo '<div class="text-xs text-gray-500">(Admin view)</div>';
        }

        echo '</div>'; // header

        echo '<div class="mt-3 text-sm text-gray-800 whitespace-pre-wrap">' . h((string)$c['body']) . '</div>';

        // images
        $imgs = comment_images($cid);
        if ($imgs) {
            echo '<div class="mt-3 grid grid-cols-2 gap-2">';
            foreach ($imgs as $p) {
                echo '<a href="' . h(APP_BASE_URL) . '/' . h($p) . '" target="_blank">';
                echo '<img src="' . h(APP_BASE_URL) . '/' . h($p) . '" class="w-full rounded-lg border" alt="comment image">';
                echo '</a>';
            }
            echo '</div>';
        }

        echo '</div>'; // card

        // children
        render_comments($byParent, $cid, $viewer, $depth + 1);
        echo '</div>';
    }
}

$reply_to = (int)($_GET['reply_to'] ?? 0);
$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h(APP_NAME) ?> - <?= h((string)$post['title']) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-50">
  <div class="max-w-5xl mx-auto p-6">
    <div class="flex items-start justify-between gap-3 flex-wrap">
      <div>
        <a class="text-sm text-gray-700 hover:underline" href="<?= h(APP_BASE_URL) ?>/blog/index.php">← Back</a>
        <h1 class="text-2xl font-bold mt-2"><?= h((string)$post['title']) ?></h1>
        <div class="text-xs text-gray-500 mt-1">
          By <span class="font-semibold"><?= h((string)$post['full_name']) ?></span>
          <span class="ml-1 px-2 py-0.5 rounded-full bg-gray-100"><?= h((string)$post['role']) ?></span>
          • <?= h((string)$post['created_at']) ?> (UTC)
        </div>
      </div>
      <div class="flex gap-2 flex-wrap">
        <?php if (is_admin()): ?>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/admin/dashboard.php">Admin Dashboard</a>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/admin/reports.php">Reports</a>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/admin/users.php">Users</a>
        <?php else: ?>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/messages/inbox.php">Messages</a>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/home.php">Home</a>
        <?php endif; ?>
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/logout.php">Logout</a>
      </div>
    </div>

    <?php if ($flash): ?>
      <div class="mt-4 p-3 rounded <?= $flash['type']==='error' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700' ?>">
        <?= h((string)$flash['message']) ?>
      </div>
    <?php endif; ?>

    <div class="mt-6 bg-white rounded-2xl shadow p-6">
      <div class="text-gray-800 whitespace-pre-wrap"><?= h((string)$post['body']) ?></div>

      <?php if ($images): ?>
        <div class="mt-4 grid grid-cols-2 md:grid-cols-3 gap-3">
          <?php foreach ($images as $p): ?>
            <a href="<?= h(APP_BASE_URL) ?>/<?= h($p) ?>" target="_blank">
              <img src="<?= h(APP_BASE_URL) ?>/<?= h($p) ?>" class="w-full rounded-lg border" alt="post image">
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <?php if (!is_admin() && (int)$post['user_id'] !== (int)$user['id']): ?>
        <div class="mt-4 flex gap-4 text-sm">
          <a class="text-blue-700 hover:underline" href="<?= h(APP_BASE_URL) ?>/messages/thread.php?user_id=<?= (int)$post['user_id'] ?>">Message author</a>
          <a class="text-red-600 hover:underline" href="<?= h(APP_BASE_URL) ?>/blog/block.php?user_id=<?= (int)$post['user_id'] ?>">Block author</a>
          <a class="text-orange-600 hover:underline" href="<?= h(APP_BASE_URL) ?>/blog/report.php?type=post&id=<?= (int)$post['id'] ?>">Report post</a>
        </div>
      <?php endif; ?>
    </div>

    <div class="mt-8">
      <h2 class="text-lg font-bold">Comments</h2>
      <p class="text-sm text-gray-600">Reply to help. You can upload images in comments too.</p>

      <?php render_comments($byParent, 0, $user, 0); ?>

      <?php if (!is_admin()): ?>
        <div id="commentform" class="mt-8 bg-white rounded-2xl shadow p-6">
          <h3 class="font-semibold"><?= $reply_to ? 'Reply to comment #' . $reply_to : 'Add a comment' ?></h3>
          <form method="post" action="<?= h(APP_BASE_URL) ?>/blog/comment_add.php" enctype="multipart/form-data" class="mt-4 space-y-4">
            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
            <input type="hidden" name="post_id" value="<?= (int)$post_id ?>">
            <input type="hidden" name="parent_id" value="<?= (int)$reply_to ?>">

            <div>
              <label class="block text-sm font-medium">Comment</label>
              <textarea name="body" rows="4" required class="mt-1 w-full rounded-lg border p-2" placeholder="Write your reply..."></textarea>
            </div>

            <div>
              <label class="block text-sm font-medium">Upload images (optional)</label>
              <input name="images[]" type="file" multiple accept="image/jpeg,image/png,image/webp" class="mt-1 w-full">
              <p class="text-xs text-gray-500 mt-1">Max <?= (int)UPLOAD_MAX_FILES ?> files, max <?= (int)(UPLOAD_MAX_BYTES/1024/1024) ?>MB each.</p>
            </div>

            <button class="bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg px-4 py-2">Post comment</button>
          </form>
        </div>
      <?php else: ?>
        <div class="mt-6 text-sm text-gray-500">Admin cannot comment.</div>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
