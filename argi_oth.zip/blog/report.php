<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

$user = require_farmer_access();
if (is_admin()) {
    flash_set('error', 'Admin cannot report.');
    redirect_path(APP_BASE_URL . '/blog/index.php');
}

$type = (string)($_GET['type'] ?? ($_POST['type'] ?? ''));
$target_id = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));

if (!in_array($type, ['post','comment'], true) || $target_id <= 0) {
    flash_set('error', 'Invalid report target.');
    redirect_path(APP_BASE_URL . '/blog/index.php');
}

// find target owner + post for redirect
$owner_id = 0;
$post_id = 0;
$title = '';
if ($type === 'post') {
    $stmt = db()->prepare('SELECT id, user_id, title FROM posts WHERE id=? AND is_deleted=0 LIMIT 1');
    $stmt->execute([$target_id]);
    $r = $stmt->fetch();
    if (!$r) {
        flash_set('error', 'Post not found.');
        redirect_path(APP_BASE_URL . '/blog/index.php');
    }
    $owner_id = (int)$r['user_id'];
    $post_id = (int)$r['id'];
    $title = (string)$r['title'];
} else {
    $stmt = db()->prepare('SELECT id, user_id, post_id FROM comments WHERE id=? AND is_deleted=0 LIMIT 1');
    $stmt->execute([$target_id]);
    $r = $stmt->fetch();
    if (!$r) {
        flash_set('error', 'Comment not found.');
        redirect_path(APP_BASE_URL . '/blog/index.php');
    }
    $owner_id = (int)$r['user_id'];
    $post_id = (int)$r['post_id'];
    $title = 'Comment #' . $target_id;
}

if ($owner_id === (int)$user['id']) {
    flash_set('error', 'You cannot report your own content.');
    redirect_path(APP_BASE_URL . '/blog/view.php?id=' . $post_id);
}

$errors = [];
$reason = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request (CSRF).';
    } else {
        $reason = trim((string)($_POST['reason'] ?? ''));
        if ($reason === '' || strlen($reason) < 5) {
            $errors[] = 'Please write a short reason.';
        }
        if (!$errors) {
            report_create((int)$user['id'], $type, $target_id, $reason);
            flash_set('success', 'Report submitted. Admin will review it.');
            redirect_path(APP_BASE_URL . '/blog/view.php?id=' . $post_id);
        }
    }
}

$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h(APP_NAME) ?> - Report</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-50 p-6">
  <div class="max-w-lg mx-auto">
    <a class="text-sm text-gray-700 hover:underline" href="<?= h(APP_BASE_URL) ?>/blog/view.php?id=<?= (int)$post_id ?>">← Back</a>
    <h1 class="text-2xl font-bold mt-2">Report <?= h($type) ?></h1>
    <p class="text-sm text-gray-600 mt-1">Target: <?= h($title) ?></p>

    <?php if ($flash): ?>
      <div class="mt-4 p-3 rounded <?= $flash['type']==='error' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700' ?>">
        <?= h((string)$flash['message']) ?>
      </div>
    <?php endif; ?>

    <?php if ($errors): ?>
      <div class="mt-4 p-3 rounded bg-red-50 text-red-700">
        <ul class="list-disc pl-5 space-y-1">
          <?php foreach ($errors as $e): ?><li><?= h((string)$e) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="post" class="mt-6 bg-white rounded-2xl shadow p-6 space-y-4">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <input type="hidden" name="type" value="<?= h($type) ?>">
      <input type="hidden" name="id" value="<?= (int)$target_id ?>">

      <div>
        <label class="block text-sm font-medium">Reason</label>
        <textarea name="reason" rows="4" required class="mt-1 w-full rounded-lg border p-2" placeholder="Explain what is malicious or wrong..."><?= h($reason) ?></textarea>
        <p class="text-xs text-gray-500 mt-1">Example: spam, abuse, hate speech, scam link, harassment.</p>
      </div>

      <button class="w-full bg-orange-600 hover:bg-orange-700 text-white font-semibold rounded-lg py-2">Submit report</button>
    </form>
  </div>
</body>
</html>
