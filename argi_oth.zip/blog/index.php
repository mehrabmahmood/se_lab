<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

// Community Blog is for Farmers (Admin can view for moderation)
$user = require_farmer_access();
$uid = is_admin() ? 0 : (int)$user['id'];

// Load posts
if (is_admin()) {
    $stmt = db()->query(
        "SELECT p.*, u.full_name, u.role,
            (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id AND c.is_deleted=0) AS comment_count
         FROM posts p JOIN users u ON u.id=p.user_id
         WHERE p.is_deleted=0
         ORDER BY p.created_at DESC
         LIMIT 50"
    );
    $posts = $stmt->fetchAll();
} else {
    $posts = posts_list($uid, 50);
}

function dashboard_link(array $u): string {
    if (is_admin()) return APP_BASE_URL . '/admin/dashboard.php';
    $role = (string)($u['role'] ?? 'farmer');
    if ($role === 'volunteer') return APP_BASE_URL . '/dashboard_volunteer.php';
    if ($role === 'vet') return APP_BASE_URL . '/dashboard_vet.php';
    return APP_BASE_URL . '/home.php';
}

$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h(APP_NAME) ?> - Community Blog</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-50">
  <div class="max-w-5xl mx-auto p-6">
    <div class="flex items-center justify-between gap-3 flex-wrap">
      <div>
        <h1 class="text-2xl font-bold">Community Blog</h1>
        <p class="text-sm text-gray-600">Ask questions, share problems, help each other.</p>
      </div>
      <div class="flex gap-2 flex-wrap">
        <?php if (is_admin()): ?>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/admin/dashboard.php">Admin Dashboard</a>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/admin/reports.php">Reports</a>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/admin/users.php">Users</a>
        <?php else: ?>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(dashboard_link($user)) ?>">Home</a>
          <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/messages/inbox.php">Messages</a>
          <a class="px-3 py-2 rounded-lg bg-green-600 text-white text-sm" href="<?= h(APP_BASE_URL) ?>/blog/new.php">New Post</a>
        <?php endif; ?>
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/logout.php">Logout</a>
      </div>
    </div>

    <?php if ($flash): ?>
      <div class="mt-4 p-3 rounded <?= $flash['type']==='error' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700' ?>">
        <?= h((string)$flash['message']) ?>
      </div>
    <?php endif; ?>

    <div class="mt-6 space-y-4">
      <?php if (!$posts): ?>
        <div class="bg-white rounded-2xl shadow p-6 text-gray-600">No posts yet. Create the first post!</div>
      <?php endif; ?>

      <?php foreach ($posts as $p): ?>
        <div class="bg-white rounded-2xl shadow p-5">
          <div class="flex items-start justify-between gap-3">
            <div>
              <a class="text-lg font-semibold hover:underline" href="<?= h(APP_BASE_URL) ?>/blog/view.php?id=<?= (int)$p['id'] ?>">
                <?= h((string)$p['title']) ?>
              </a>
              <div class="text-xs text-gray-500 mt-1">
                By <span class="font-semibold"><?= h((string)$p['full_name']) ?></span>
                <span class="ml-1 px-2 py-0.5 rounded-full bg-gray-100"><?= h((string)$p['role']) ?></span>
                • <?= h((string)$p['created_at']) ?> (UTC)
                • <?= (int)$p['comment_count'] ?> comments
              </div>
            </div>

            <?php if (!is_admin()): ?>
              <div class="flex gap-2">
                <a class="text-xs text-blue-700 hover:underline" href="<?= h(APP_BASE_URL) ?>/messages/thread.php?user_id=<?= (int)$p['user_id'] ?>">Message</a>
                <?php if ((int)$p['user_id'] !== (int)$user['id']): ?>
                  <a class="text-xs text-red-600 hover:underline" href="<?= h(APP_BASE_URL) ?>/blog/block.php?user_id=<?= (int)$p['user_id'] ?>">Block</a>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>

          <p class="mt-3 text-sm text-gray-700">
            <?= h(mb_strimwidth((string)$p['body'], 0, 300, '...')) ?>
          </p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</body>
</html>
