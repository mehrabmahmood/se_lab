<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

$user = require_farmer_access();
$uid = (int)$user['id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_path(APP_BASE_URL . '/blog/index.php');
}

if (!csrf_verify($_POST['csrf_token'] ?? '')) {
    flash_set('error', 'Invalid request (CSRF).');
    redirect_path(APP_BASE_URL . '/blog/index.php');
}

$post_id = (int)($_POST['post_id'] ?? 0);
$parent_id = (int)($_POST['parent_id'] ?? 0);
$body = trim((string)($_POST['body'] ?? ''));

if ($post_id <= 0 || $body === '') {
    flash_set('error', 'Comment data missing.');
    redirect_path(APP_BASE_URL . '/blog/view.php?id=' . $post_id);
}

// Ensure post exists and is visible (not blocked)
$post = post_get($uid, $post_id);
if (!$post) {
    flash_set('error', 'Post not found (maybe blocked).');
    redirect_path(APP_BASE_URL . '/blog/index.php');
}

// Validate parent comment
if ($parent_id > 0) {
    $stmt = db()->prepare('SELECT id, post_id, user_id FROM comments WHERE id=? AND is_deleted=0 LIMIT 1');
    $stmt->execute([$parent_id]);
    $parent = $stmt->fetch();
    if (!$parent || (int)$parent['post_id'] !== $post_id) {
        $parent_id = 0; // ignore invalid parent
    } else {
        $other = (int)$parent['user_id'];
        if (is_blocked_any_direction($uid, $other)) {
            flash_set('error', 'You cannot reply because one of you has blocked the other.');
            redirect_path(APP_BASE_URL . '/blog/view.php?id=' . $post_id);
        }
    }
}

// If you are blocked by the post author or you blocked them, deny commenting
$author_id = (int)$post['user_id'];
if ($author_id !== $uid && is_blocked_any_direction($uid, $author_id)) {
    flash_set('error', 'You cannot comment because one of you has blocked the other.');
    redirect_path(APP_BASE_URL . '/blog/view.php?id=' . $post_id);
}

$paths = [];
if (!empty($_FILES['images'])) {
    $paths = upload_images($_FILES['images'], 'comments');
}

$cid = comment_create($uid, $post_id, $parent_id > 0 ? $parent_id : null, $body, $paths);
flash_set('success', 'Comment posted.');
redirect_path(APP_BASE_URL . '/blog/view.php?id=' . $post_id . '#c' . $cid);
