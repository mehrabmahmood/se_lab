<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

$user = require_farmer_access();
if (is_admin()) redirect_path(APP_BASE_URL . '/blog/index.php');

$me = (int)$user['id'];
$other = (int)($_GET['user_id'] ?? 0);
$back = $_SERVER['HTTP_REFERER'] ?? (APP_BASE_URL . '/blog/index.php');

if ($other <= 0 || $other === $me) {
    flash_set('error', 'Invalid user.');
    redirect_path($back);
}

// check current state
$stmt = db()->prepare('SELECT 1 FROM blocks WHERE blocker_id=? AND blocked_id=? LIMIT 1');
$stmt->execute([$me, $other]);
$exists = (bool)$stmt->fetchColumn();

if ($exists) {
    block_remove($me, $other);
    flash_set('success', 'User unblocked.');
} else {
    block_add($me, $other);
    flash_set('success', 'User blocked. You will not see their posts/comments, and messaging is disabled.');
}

redirect_path($back);
