<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_path(APP_BASE_URL . '/admin/dashboard.php');
}

if (!csrf_verify($_POST['csrf_token'] ?? '')) {
    flash_set('error', 'Invalid request (CSRF).');
    redirect_path(APP_BASE_URL . '/admin/dashboard.php');
}

$action = (string)($_POST['action'] ?? '');
$user_id = (int)($_POST['user_id'] ?? 0);
$report_id = (int)($_POST['report_id'] ?? 0);
$reason = trim((string)($_POST['reason'] ?? ''));
$days = (int)($_POST['days'] ?? 7);
$note = trim((string)($_POST['note'] ?? ''));

// Never allow actions for invalid user id
if (in_array($action, ['ban_temp','ban_perm','unban'], true) && $user_id <= 0) {
    flash_set('error', 'Invalid user id.');
    redirect_path(APP_BASE_URL . '/admin/dashboard.php');
}

try {
    switch ($action) {
        case 'ban_temp': {
            $days = $days > 0 ? $days : 7;
            $reason = $reason !== '' ? $reason : 'Admin temp ban';
            admin_ban_user_temp($user_id, $days, $reason);
            if ($report_id > 0) {
                $adminNote = $note !== '' ? $note : ('Banned user (temp ' . $days . ' days).');
                report_mark_reviewed($report_id, ADMIN_EMAIL, $adminNote);
            }
            flash_set('success', 'User banned for ' . $days . ' days.');
            break;
        }
        case 'ban_perm': {
            $reason = $reason !== '' ? $reason : 'Admin permanent ban';
            admin_ban_user_perm($user_id, $reason);
            if ($report_id > 0) {
                $adminNote = $note !== '' ? $note : 'Banned user (permanent).';
                report_mark_reviewed($report_id, ADMIN_EMAIL, $adminNote);
            }
            flash_set('success', 'User banned permanently.');
            break;
        }
        case 'unban': {
            admin_unban_user($user_id);
            flash_set('success', 'User unbanned.');
            break;
        }
        case 'review': {
            if ($report_id <= 0) {
                flash_set('error', 'Invalid report id.');
                break;
            }
            report_mark_reviewed($report_id, ADMIN_EMAIL, $note !== '' ? $note : 'Reviewed.');
            flash_set('success', 'Report marked as reviewed.');
            break;
        }
        case 'dismiss': {
            if ($report_id <= 0) {
                flash_set('error', 'Invalid report id.');
                break;
            }
            report_mark_reviewed($report_id, ADMIN_EMAIL, $note !== '' ? $note : 'Dismissed.');
            flash_set('success', 'Report dismissed.');
            break;
        }
        default:
            flash_set('error', 'Unknown action.');
    }
} catch (Throwable $e) {
    flash_set('error', 'Action failed: ' . $e->getMessage());
}

// Redirect back to the page the admin came from, or dashboard
$back = (string)($_SERVER['HTTP_REFERER'] ?? '');
if ($back === '') {
    $back = APP_BASE_URL . '/admin/dashboard.php';
}
redirect_path($back);
