<?php
declare(strict_types=1);

require_once __DIR__ . '/../functions.php';
require_admin();

$reports = reports_open_list(300);
$flash = flash_get();
$csrf = csrf_token();

// Helper: load target details
function load_target(string $type, int $id): ?array {
    if ($type === 'post') {
        $stmt = db()->prepare(
            "SELECT p.id, p.title, p.body, p.user_id, p.created_at, u.full_name, u.email, u.role, u.ban_type, u.ban_until
             FROM posts p JOIN users u ON u.id=p.user_id
             WHERE p.id=? AND p.is_deleted=0 LIMIT 1"
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row) return null;
        $row['post_id'] = (int)$row['id'];
        $row['comment_id'] = 0;
        return $row;
    }

    if ($type === 'comment') {
        $stmt = db()->prepare(
            "SELECT c.id AS comment_id, c.post_id, c.body, c.user_id, c.created_at, u.full_name, u.email, u.role, u.ban_type, u.ban_until
             FROM comments c JOIN users u ON u.id=c.user_id
             WHERE c.id=? AND c.is_deleted=0 LIMIT 1"
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row) return null;
        $row['id'] = (int)$row['comment_id'];
        $row['title'] = 'Comment #' . (int)$row['comment_id'];
        return $row;
    }

    return null;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h(APP_NAME) ?> - Admin Reports</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-50 p-6">
  <div class="max-w-6xl mx-auto">
    <div class="flex items-center justify-between gap-3 flex-wrap">
      <div>
        <h1 class="text-2xl font-bold">Reports</h1>
        <p class="text-sm text-gray-600">Review reported posts/comments, then ban for 1 week or lifetime if needed.</p>
      </div>
      <div class="flex gap-2 flex-wrap">
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/admin/dashboard.php">Admin Dashboard</a>
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/admin/users.php">Users</a>
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/logout.php">Logout</a>
      </div>
    </div>

    <?php if ($flash): ?>
      <div class="mt-4 p-3 rounded <?= $flash['type']==='error' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700' ?>">
        <?= h((string)$flash['message']) ?>
      </div>
    <?php endif; ?>

    <div class="mt-6">
      <?php if (!$reports): ?>
        <div class="bg-white rounded-2xl shadow p-6 text-gray-600">No open reports.</div>
      <?php endif; ?>

      <div class="space-y-4">
        <?php foreach ($reports as $r): ?>
          <?php
            $type = (string)$r['target_type'];
            $tid  = (int)$r['target_id'];
            $target = load_target($type, $tid);
          ?>
          <div class="bg-white rounded-2xl shadow p-6">
            <div class="flex items-start justify-between gap-4 flex-wrap">
              <div>
                <div class="text-sm text-gray-500">Report #<?= (int)$r['id'] ?> • <?= h((string)$r['created_at']) ?> (UTC)</div>
                <div class="mt-1 font-semibold">Target: <?= h($type) ?> #<?= (int)$tid ?></div>
                <div class="text-sm text-gray-600 mt-1">Reason: <?= h((string)$r['reason']) ?></div>
                <div class="text-xs text-gray-500 mt-2">Reporter: <?= h((string)$r['reporter_name']) ?> (<?= h((string)$r['reporter_email']) ?>)</div>
              </div>

              <div class="flex gap-2 flex-wrap">
                <form method="post" action="<?= h(APP_BASE_URL) ?>/admin/actions.php" class="inline">
                  <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
                  <input type="hidden" name="action" value="dismiss">
                  <input type="hidden" name="report_id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="note" value="Dismissed - no action needed">
                  <button class="px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-sm">Dismiss</button>
                </form>

                <form method="post" action="<?= h(APP_BASE_URL) ?>/admin/actions.php" class="inline">
                  <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
                  <input type="hidden" name="action" value="review">
                  <input type="hidden" name="report_id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="note" value="Reviewed">
                  <button class="px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm">Mark Reviewed</button>
                </form>
              </div>
            </div>

            <?php if (!$target): ?>
              <div class="mt-4 text-sm text-gray-600">Target content was not found (maybe deleted). You can dismiss this report.</div>
            <?php else: ?>
              <?php
                $offender_id = (int)$target['user_id'];
                $ban_type = (string)($target['ban_type'] ?? 'none');
                $ban_until = (string)($target['ban_until'] ?? '');
                $viewLink = '';
                if ($type === 'post') {
                    $viewLink = APP_BASE_URL . '/blog/view.php?id=' . (int)$target['post_id'];
                } else {
                    $viewLink = APP_BASE_URL . '/blog/view.php?id=' . (int)$target['post_id'] . '#c' . (int)$target['comment_id'];
                }
              ?>

              <div class="mt-4 grid md:grid-cols-3 gap-4">
                <div class="md:col-span-2">
                  <div class="text-sm font-semibold">Content preview</div>
                  <div class="mt-2 p-3 rounded-lg bg-gray-50 text-sm whitespace-pre-wrap">
                    <?= h(mb_strimwidth((string)$target['body'], 0, 700, '...')) ?>
                  </div>
                  <a class="inline-block mt-2 text-sm text-green-700 hover:underline" href="<?= h($viewLink) ?>" target="_blank">Open in Blog</a>
                </div>

                <div>
                  <div class="text-sm font-semibold">Reported user</div>
                  <div class="mt-2 text-sm">
                    <div><span class="text-gray-500">Name:</span> <?= h((string)$target['full_name']) ?></div>
                    <div><span class="text-gray-500">Email:</span> <?= h((string)$target['email']) ?></div>
                    <div><span class="text-gray-500">Role:</span> <?= h((string)$target['role']) ?></div>
                    <div class="mt-2"><span class="text-gray-500">Ban:</span> <?= h($ban_type) ?><?= $ban_until ? ' until ' . h($ban_until) . ' (UTC)' : '' ?></div>
                  </div>

                  <div class="mt-3 flex flex-col gap-2">
                    <form method="post" action="<?= h(APP_BASE_URL) ?>/admin/actions.php" onsubmit="return confirm('Ban this user for 7 days?');">
                      <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
                      <input type="hidden" name="action" value="ban_temp">
                      <input type="hidden" name="user_id" value="<?= (int)$offender_id ?>">
                      <input type="hidden" name="days" value="7">
                      <input type="hidden" name="reason" value="Banned after report #<?= (int)$r['id'] ?>">
                      <input type="hidden" name="report_id" value="<?= (int)$r['id'] ?>">
                      <input type="hidden" name="note" value="Banned user for 7 days based on this report">
                      <button class="w-full px-3 py-2 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-sm">Ban 1 Week</button>
                    </form>

                    <form method="post" action="<?= h(APP_BASE_URL) ?>/admin/actions.php" onsubmit="return confirm('Permanently ban this user?');">
                      <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
                      <input type="hidden" name="action" value="ban_perm">
                      <input type="hidden" name="user_id" value="<?= (int)$offender_id ?>">
                      <input type="hidden" name="reason" value="Permanent ban after report #<?= (int)$r['id'] ?>">
                      <input type="hidden" name="report_id" value="<?= (int)$r['id'] ?>">
                      <input type="hidden" name="note" value="Permanently banned based on this report">
                      <button class="w-full px-3 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm">Ban Lifetime</button>
                    </form>

                    <form method="post" action="<?= h(APP_BASE_URL) ?>/admin/actions.php" onsubmit="return confirm('Unban this user?');">
                      <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
                      <input type="hidden" name="action" value="unban">
                      <input type="hidden" name="user_id" value="<?= (int)$offender_id ?>">
                      <button class="w-full px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-sm">Unban</button>
                    </form>
                  </div>
                </div>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</body>
</html>
