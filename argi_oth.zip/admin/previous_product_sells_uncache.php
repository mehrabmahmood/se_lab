<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/cache_demo_helpers.php';
require_admin();

cache_demo_no_store_headers();

// Pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$auto = !empty($_GET['auto']);
$limit = 50;
$offset = ($page - 1) * $limit;

// Insecure cache: key does NOT include any user/session context.
$cacheKey = "pps:uncache:v1:page={$page}:limit={$limit}";
$ttlSeconds = (int)CACHE_DEMO_TTL_SECONDS;

$cacheDir = (string)CACHE_DEMO_PUBLIC_CACHE_DIR;
cache_demo_ensure_dir($cacheDir, false);

$cacheFileName = "pps_uncache_page{$page}_limit{$limit}.json";
$cachePath = $cacheDir . '/' . $cacheFileName;
$cachePublicUrl = APP_BASE_URL . '/cache_public/' . rawurlencode($cacheFileName);

// Actions
$flash = flash_get();
$force_refresh = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? null;
    if (!csrf_verify(is_string($token) ? $token : null)) {
        $flash = ['type' => 'error', 'message' => 'Invalid CSRF token.'];
    } else {
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'clear') {
            if (is_file($cachePath)) @unlink($cachePath);
            $flash = ['type' => 'success', 'message' => 'Unsecure cache cleared (public file deleted).'];
        } elseif ($action === 'refresh') {
            $force_refresh = true;
            $flash = ['type' => 'success', 'message' => 'Refreshed from database (public cache updated).'];
        }
    }
}

// Timing
$totalStart = microtime(true);
$cacheStatus  = 'MISS';
$cacheReadMs  = 0.0;
$dbQueryMs    = null;
$cacheWriteMs = null;
$expiresIn    = null;

$rows = [];
$generated_at = null;
$error = null;

try {
    // Treat expired cache as cleared
    if (is_file($cachePath) && (time() - (int)filemtime($cachePath) >= $ttlSeconds)) {
        @unlink($cachePath);
    }

    // 1) cache_get timing (unsecured)
    $tCacheGet = microtime(true);
    $payload = null;
    if (!$force_refresh && is_file($cachePath)) {
        $payload = cache_demo_read_json($cachePath);
    }
    $cacheReadMs = round((microtime(true) - $tCacheGet) * 1000, 2);

    if (is_array($payload) && isset($payload['rows']) && is_array($payload['rows'])) {
        $cacheStatus = 'HIT';
        $rows = $payload['rows'];
        $generated_at = (string)($payload['generated_at'] ?? '');
        $expiresIn = max(0, $ttlSeconds - (time() - (int)filemtime($cachePath)));
    }

    if ($cacheStatus !== 'HIT') {
        // 2) DB query timing
        $pdo = cache_db();
        $tDb = microtime(true);
        $stmt = $pdo->prepare(
            'SELECT id, product_name, quantity, unit_price, sold_at, buyer_name, notes '
            . 'FROM previous_product_sells '
            . 'ORDER BY sold_at DESC '
            . 'LIMIT :lim OFFSET :off'
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':off', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        $dbQueryMs = round((microtime(true) - $tDb) * 1000, 2);

        $generated_at = gmdate('Y-m-d H:i:s') . ' UTC';

        // 3) cache_set timing (unsecured)
        $tCacheSet = microtime(true);
        cache_demo_write_json_atomic($cachePath, [
            'cacheKey' => $cacheKey,
            'generated_at' => $generated_at,
            'rows' => $rows,
        ]);
        $cacheWriteMs = round((microtime(true) - $tCacheSet) * 1000, 2);

        $expiresIn = $ttlSeconds;
    }
} catch (Throwable $t) {
    $error = $t->getMessage();
    $rows = [];
}

$totalMs = round((microtime(true) - $totalStart) * 1000, 2);

// Summary stats
$total_qty = 0;
$total_revenue = 0.0;
foreach ($rows as $r) {
    $q = (int)($r['quantity'] ?? 0);
    $p = (float)($r['unit_price'] ?? 0);
    $total_qty += $q;
    $total_revenue += ($q * $p);
}

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Unsecure Caching - Previous Product Sells</title>
  <link rel="stylesheet" href="<?= h(APP_BASE_URL) ?>/assets/cache-demo.css">
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="row" style="align-items:center; justify-content: space-between;">
        <div class="col" style="min-width: 320px;">
          <h1>Unsecure Caching (Timed)</h1>
          <small>
            Separate DB: <b><?= h(CACHE_DB_NAME) ?></b> · TTL: <b><?= (int)$ttlSeconds ?>s</b> · Cache file stored in a <b>public folder</b> (web-accessible).
          </small>
        </div>
        <div class="col" style="text-align:right; min-width: 220px;">
          <a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells.php">&larr; Modes</a>
        </div>
      </div>

      <?php if ($flash): ?>
        <hr>
        <div class="badge <?= $flash['type']==='error' ? 'warn' : 'good' ?>"><?= h((string)$flash['message']) ?></div>
      <?php endif; ?>

      <hr>
      <p>
        <span class="badge <?= $cacheStatus==='HIT' ? 'good' : 'warn' ?>">CACHE <?= h($cacheStatus) ?></span>
        <span class="badge">TTL: <?= (int)$ttlSeconds ?>s</span>
        <span class="badge">Limit: <?= (int)$limit ?></span>
        <span class="badge">Page: <?= (int)$page ?></span>
        <?php if ($expiresIn !== null): ?>
          <span class="badge">Expires in: <b id="expires"><?= (int)$expiresIn ?></b>s</span>
        <?php endif; ?>
      </p>

      <p>
        <span class="badge">Total server time: <b><?= h((string)$totalMs) ?> ms</b></span>
        <span class="badge">cache_get(): <b><?= h((string)$cacheReadMs) ?> ms</b></span>
        <?php if ($dbQueryMs !== null): ?>
          <span class="badge">DB query: <b><?= h((string)$dbQueryMs) ?> ms</b></span>
        <?php else: ?>
          <span class="badge">DB query: <b>skipped (HIT)</b></span>
        <?php endif; ?>
        <?php if ($cacheWriteMs !== null): ?>
          <span class="badge">cache_set(): <b><?= h((string)$cacheWriteMs) ?> ms</b></span>
        <?php else: ?>
          <span class="badge">cache_set(): <b>skipped (HIT)</b></span>
        <?php endif; ?>
      </p>

      <p>
        <a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells_secure.php">Secure cache</a> ·
        <a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells_nocache.php">No cache</a>
      </p>

      <p>
        <small>
          Auto reload on expiry: 
          <?php if ($auto): ?>
            <b>ON</b> · <a href="?page=<?= (int)$page ?>">Turn OFF</a>
          <?php else: ?>
            <b>OFF</b> · <a href="?page=<?= (int)$page ?>&auto=1">Turn ON</a>
          <?php endif; ?>
        </small>
      </p>

      <p>
        <span class="badge warn">Public cache file:</span>
        <a href="<?= h($cachePublicUrl) ?>" target="_blank" rel="noopener">Open cached file</a>
        <small style="display:block; margin-top:6px;">(Teacher demo: you can see the cached JSON directly in the browser.)</small>
      </p>

      <div class="row" style="align-items:center; justify-content: flex-end;">
        <form method="post" style="display:inline-block;">
          <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
          <input type="hidden" name="action" value="refresh">
          <button type="submit">Refresh from DB</button>
        </form>
        <form method="post" style="display:inline-block; margin-left:8px;">
          <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
          <input type="hidden" name="action" value="clear">
          <button type="submit">Clear Cache</button>
        </form>
      </div>
    </div>

    <?php if ($error): ?>
      <div class="card">
        <h2>Database not ready</h2>
        <p><small>Create the demo DB using: <b>agrimo-auth/sql/cache_demo_schema.sql</b></small></p>
        <pre style="white-space: pre-wrap; background:#fafafa; border:1px solid #eee; padding:12px; border-radius:12px; overflow:auto;"><?= h((string)$error) ?></pre>
      </div>
    <?php else: ?>
      <div class="card">
        <h2>Summary</h2>
        <div class="row">
          <div class="col"><div class="badge">Rows: <?= (int)count($rows) ?></div></div>
          <div class="col"><div class="badge">Total quantity: <?= (int)$total_qty ?></div></div>
          <div class="col"><div class="badge">Total revenue: <?= h(number_format($total_revenue, 2)) ?></div></div>
        </div>
      </div>

      <div class="card">
        <h2>Previous product sells (page <?= (int)$page ?>)</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th><th>Product</th><th>Qty</th><th>Unit Price</th><th>Sold at</th><th>Buyer</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$rows): ?>
              <tr><td colspan="6"><small>No data yet. Insert demo rows into <?= h(CACHE_DB_NAME) ?>.previous_product_sells</small></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td><?= (int)$r['id'] ?></td>
                <td><?= h((string)$r['product_name']) ?></td>
                <td><?= (int)$r['quantity'] ?></td>
                <td><?= h(number_format((float)$r['unit_price'], 2)) ?></td>
                <td><?= h((string)$r['sold_at']) ?></td>
                <td><?= h((string)($r['buyer_name'] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <p style="margin-top:12px;">
          <a href="?page=<?= max(1, $page-1) ?>">&laquo; Prev</a> |
          <a href="?page=<?= $page+1 ?>">Next &raquo;</a>
        </p>
      </div>

      <div class="card">
        <h2>Why this is Unsecure Caching</h2>
        <ul>
          <li>Cache is stored in <b>/cache_public</b>, which is <b>web-accessible</b> (anyone can open the JSON URL).</li>
          <li>No signature or encryption: cached data can be <b>modified</b> and the app would still treat it as valid on HIT.</li>
          <li>Cache key does not include user/session context; it is easier to reuse across users/pages incorrectly.</li>
          <li>Cache is treated as expired (cleared) after <b><?= (int)$ttlSeconds ?> seconds</b>.</li>
        </ul>
      </div>
    <?php endif; ?>

  </div>

  <?php if ($expiresIn !== null): ?>
  <script>
    (function () {
      var el = document.getElementById('expires');
      if (!el) return;
      var seconds = parseInt(el.textContent, 10);
      if (!isFinite(seconds)) return;
      setInterval(function () {
        seconds = Math.max(0, seconds - 1);
        el.textContent = String(seconds);
        if (seconds === 0 && <?= $auto ? 'true' : 'false' ?>) {
          location.reload();
        }
      }, 1000);
    })();
  </script>
  <?php endif; ?>
</body>
</html>
