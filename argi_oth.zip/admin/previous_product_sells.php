<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/cache_demo_helpers.php';
require_admin();

cache_demo_no_store_headers();

$ttl = (int)CACHE_DEMO_TTL_SECONDS;

// Light readiness check for the separate demo DB
$db_ready = true;
$db_error = null;
try {
    cache_db()->query('SELECT 1');
} catch (Throwable $t) {
    $db_ready = false;
    $db_error = $t->getMessage();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= h(APP_NAME) ?> - Cache Demo (Previous Product Sells)</title>
  <link rel="stylesheet" href="<?= h(APP_BASE_URL) ?>/assets/cache-demo.css" />
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="row" style="align-items:center; justify-content: space-between;">
        <div class="col" style="min-width: 320px;">
          <h1>Previous Product Sells - Cache Demo</h1>
          <small>
            This demo uses a <b>separate database</b> (<?= h(CACHE_DB_NAME) ?>).
            It shows <b>three modes</b>: secure cache, insecure cache, and no cache.
            TTL: <b><?= (int)$ttl ?> seconds</b>.
          </small>
        </div>
        <div class="col" style="text-align:right; min-width: 220px;">
          <a href="<?= h(APP_BASE_URL) ?>/admin/dashboard.php">&larr; Back to Dashboard</a>
        </div>
      </div>

      <?php if (!$db_ready): ?>
        <hr>
        <div class="badge warn">Database not ready</div>
        <p style="margin-top:10px;"><small>
          Please create the demo DB by running: <b>agrimo-auth/sql/cache_demo_schema.sql</b>
        </small></p>
        <pre style="white-space: pre-wrap; background:#fafafa; border:1px solid #eee; padding:12px; border-radius:12px; overflow:auto;"><?= h((string)$db_error) ?></pre>
      <?php endif; ?>
    </div>

    <div class="card">
      <h2>Choose a mode</h2>
      <div class="row">
        <div class="col">
          <p><span class="badge good">SECURE CACHING</span></p>
          <p><small>
            Server-side cache stored under <b>/storage</b> (not web accessible) and <b>HMAC-signed</b>.
            Shows HIT/MISS and timing. Auto-expires after <?= (int)$ttl ?>s.
          </small></p>
          <p><a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells_secure.php">Open Secure Caching</a></p>
        </div>

        <div class="col">
          <p><span class="badge warn">UNSECURE CACHING</span></p>
          <p><small>
            Cache saved in a <b>public folder</b> (web accessible). Anyone can read/modify the cached file.
            This demonstrates why public caching is unsafe.
          </small></p>
          <p><a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells_uncache.php">Open Unsecure Caching</a></p>
        </div>

        <div class="col">
          <p><span class="badge">NO CACHING</span></p>
          <p><small>
            Every page load queries the database. No cache HIT/MISS. Shows DB query time.
          </small></p>
          <p><a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells_nocache.php">Open No Caching</a></p>
        </div>
      </div>
    </div>

  </div>
</body>
</html>
