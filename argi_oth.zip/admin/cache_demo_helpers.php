<?php

declare(strict_types=1);

/**
 * Helpers for the admin caching demo (secure cache / insecure cache / no cache).
 *
 * NOTE:
 * - These helpers assume config.php has already been loaded (via functions.php).
 */

function cache_demo_no_store_headers(): void {
    // Prevent browser/proxy caching from hiding the demo effect.
    if (!headers_sent()) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
}

function cache_demo_ensure_dir(string $dir, bool $deny_web_access = false): void {
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }

    if ($deny_web_access) {
        // Defensive: even if /storage is already protected, keep cache dirs blocked.
        $ht = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . '.htaccess';
        if (!file_exists($ht)) {
            @file_put_contents($ht, "Deny from all\n");
        }
    }
}

function cache_demo_read_json(string $path): ?array {
    if (!is_file($path)) return null;
    $raw = @file_get_contents($path);
    if ($raw === false) return null;
    $json = json_decode($raw, true);
    return is_array($json) ? $json : null;
}

function cache_demo_write_json_atomic(string $path, array $payload): void {
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $tmp = $path . '.tmp';
    @file_put_contents($tmp, json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    @rename($tmp, $path);
}

function cache_demo_payload_hmac(array $payload): string {
    // Use a server-side secret; CSRF_KEY already exists and is secret.
    $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) $json = '';
    return hash_hmac('sha256', $json, (string)CSRF_KEY);
}
