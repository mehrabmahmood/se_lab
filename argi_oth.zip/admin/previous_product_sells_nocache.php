<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/cache_demo_helpers.php';
require_admin();

cache_demo_no_store_headers();

// Pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 50;
$offset = ($page - 1) * $limit;

$ttlSeconds = (int)CACHE_DEMO_TTL_SECONDS;

// Timing
$totalStart = microtime(true);
$dbQueryMs = null;

$rows = [];
$error = null;

try {
    $pdo = cache_db();
    $tDb = microtime(true);
    $stmt = $pdo->prepare(
        'SELECT id, product_name, quantity, unit_price, sold_at, buyer_name, notes '
        . 'FROM previous_product_sells '
        . 'ORDER BY sold_at DESC '
        . 'LIMIT :lim OFFSET :off'
    );
    $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':off', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();
    $dbQueryMs = round((microtime(true) - $tDb) * 1000, 2);
} catch (Throwable $t) {
    $error = $t->getMessage();
    $rows = [];
}

$totalMs = round((microtime(true) - $totalStart) * 1000, 2);

// Summary stats
$total_qty = 0;
$total_revenue = 0.0;
foreach ($rows as $r) {
    $q = (int)($r['quantity'] ?? 0);
    $p = (float)($r['unit_price'] ?? 0);
    $total_qty += $q;
    $total_revenue += ($q * $p);
}

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>No Caching - Previous Product Sells</title>
  <link rel="stylesheet" href="<?= h(APP_BASE_URL) ?>/assets/cache-demo.css">
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="row" style="align-items:center; justify-content: space-between;">
        <div class="col" style="min-width: 320px;">
          <h1>No Caching (Timed)</h1>
          <small>
            Separate DB: <b><?= h(CACHE_DB_NAME) ?></b> · Every request calls the DB. (TTL shown only to compare with cache pages: <?= (int)$ttlSeconds ?>s)
          </small>
        </div>
        <div class="col" style="text-align:right; min-width: 220px;">
          <a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells.php">&larr; Modes</a>
        </div>
      </div>

      <hr>
      <p>
        <span class="badge">NO CACHE</span>
        <span class="badge">Limit: <?= (int)$limit ?></span>
        <span class="badge">Page: <?= (int)$page ?></span>
      </p>

      <p>
        <span class="badge">Total server time: <b><?= h((string)$totalMs) ?> ms</b></span>
        <span class="badge">DB query: <b><?= $dbQueryMs !== null ? h((string)$dbQueryMs) . ' ms' : 'failed' ?></b></span>
      </p>

      <p>
        <a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells_secure.php">Secure cache</a> ·
        <a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells_uncache.php">Unsecure cache</a>
      </p>
    </div>

    <?php if ($error): ?>
      <div class="card">
        <h2>Database not ready</h2>
        <p><small>Create the demo DB using: <b>agrimo-auth/sql/cache_demo_schema.sql</b></small></p>
        <pre style="white-space: pre-wrap; background:#fafafa; border:1px solid #eee; padding:12px; border-radius:12px; overflow:auto;"><?= h((string)$error) ?></pre>
      </div>
    <?php else: ?>
      <div class="card">
        <h2>Summary</h2>
        <div class="row">
          <div class="col"><div class="badge">Rows: <?= (int)count($rows) ?></div></div>
          <div class="col"><div class="badge">Total quantity: <?= (int)$total_qty ?></div></div>
          <div class="col"><div class="badge">Total revenue: <?= h(number_format($total_revenue, 2)) ?></div></div>
        </div>
      </div>

      <div class="card">
        <h2>Previous product sells (page <?= (int)$page ?>)</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th><th>Product</th><th>Qty</th><th>Unit Price</th><th>Sold at</th><th>Buyer</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$rows): ?>
              <tr><td colspan="6"><small>No data yet. Insert demo rows into <?= h(CACHE_DB_NAME) ?>.previous_product_sells</small></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td><?= (int)$r['id'] ?></td>
                <td><?= h((string)$r['product_name']) ?></td>
                <td><?= (int)$r['quantity'] ?></td>
                <td><?= h(number_format((float)$r['unit_price'], 2)) ?></td>
                <td><?= h((string)$r['sold_at']) ?></td>
                <td><?= h((string)($r['buyer_name'] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <p style="margin-top:12px;">
          <a href="?page=<?= max(1, $page-1) ?>">&laquo; Prev</a> |
          <a href="?page=<?= $page+1 ?>">Next &raquo;</a>
        </p>
      </div>

      <div class="card">
        <h2>Why this is No Caching</h2>
        <ul>
          <li>No cache_get / cache_set: every request runs the DB query again.</li>
          <li>DB load increases as traffic increases; response is usually slower than a cache HIT.</li>
        </ul>
      </div>
    <?php endif; ?>

  </div>
</body>
</html>
