<?php

declare(strict_types=1);

/**
 * Replace this file as:
 *   C:\xampp\htdocs\agrimo-auth\admin\users.php
 *
 * Fixes:
 * - Unknown column 'ban_type'
 * - MariaDB error: SHOW COLUMNS ... LIKE ? (placeholders not allowed)
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../session.php';

require_admin();

function h_local(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * MariaDB-safe column existence check (no prepared placeholder in SHOW COLUMNS LIKE).
 */
function column_exists(string $table, string $column): bool {
    $pdo = db();

    // Escape for LIKE pattern and SQL string
    $col = addcslashes($column, "\\'%_");
    $sql = "SHOW COLUMNS FROM `$table` LIKE '{$col}'";
    $stmt = $pdo->query($sql);

    return (bool)$stmt->fetch();
}

/**
 * Adds ban columns if missing.
 * Returns array of error messages (empty array means success).
 */
function ensure_ban_columns(): array {
    $pdo = db();
    $errors = [];

    if (!column_exists('users', 'ban_type')) {
        try {
            $pdo->exec("ALTER TABLE `users`
                ADD COLUMN `ban_type` ENUM('none','temp','perm') NOT NULL DEFAULT 'none'");
        } catch (Throwable $e) {
            $errors[] = "ban_type: " . $e->getMessage();
        }
    }

    if (!column_exists('users', 'ban_until')) {
        try {
            $pdo->exec("ALTER TABLE `users`
                ADD COLUMN `ban_until` DATETIME NULL");
        } catch (Throwable $e) {
            $errors[] = "ban_until: " . $e->getMessage();
        }
    }

    if (!column_exists('users', 'ban_reason')) {
        try {
            $pdo->exec("ALTER TABLE `users`
                ADD COLUMN `ban_reason` VARCHAR(255) NULL");
        } catch (Throwable $e) {
            $errors[] = "ban_reason: " . $e->getMessage();
        }
    }

    if (!column_exists('users', 'banned_at')) {
        try {
            $pdo->exec("ALTER TABLE `users`
                ADD COLUMN `banned_at` DATETIME NULL");
        } catch (Throwable $e) {
            $errors[] = "banned_at: " . $e->getMessage();
        }
    }

    return $errors;
}

$csrf = csrf_token();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid CSRF token. Refresh and try again.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'add_ban_columns') {
            $errors = ensure_ban_columns();
            if (empty($errors) && column_exists('users', 'ban_type')) {
                header('Location: ' . APP_BASE_URL . '/admin/users.php');
                exit;
            }
        }
    }
}

// If ban columns still missing, show upgrade page and stop BEFORE loading functions.php
if (!column_exists('users', 'ban_type')): ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Users - DB Update Needed</title>
</head>
<body>
  <h1>Database Update Needed</h1>
  <p>Your <code>users</code> table is missing ban columns (ban_type, ban_until, ban_reason, banned_at).</p>
  <p>This is why you got: <b>Unknown column 'ban_type'</b>.</p>

  <?php if (!empty($errors)): ?>
    <h3>Auto-fix errors:</h3>
    <ul>
      <?php foreach ($errors as $err): ?>
        <li><?= h_local($err) ?></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

  <form method="post" action="">
    <input type="hidden" name="csrf_token" value="<?= h_local($csrf) ?>">
    <input type="hidden" name="action" value="add_ban_columns">
    <button type="submit">Add ban columns now</button>
  </form>

  <h3>Manual SQL (if button fails)</h3>
  <p>Run this in phpMyAdmin → SQL tab:</p>
  <pre>ALTER TABLE `users`
  ADD COLUMN `ban_type` ENUM('none','temp','perm') NOT NULL DEFAULT 'none',
  ADD COLUMN `ban_until` DATETIME NULL,
  ADD COLUMN `ban_reason` VARCHAR(255) NULL,
  ADD COLUMN `banned_at` DATETIME NULL;</pre>

  <p><a href="<?= h_local(APP_BASE_URL) ?>/admin/dashboard.php">Back to Admin Dashboard</a></p>
</body>
</html>
<?php exit; endif; ?>

<?php
// Now safe to load functions.php (users_list uses ban_type etc.)
require_once __DIR__ . '/../functions.php';

$users = users_list(500);
$flash = flash_get();
$csrf  = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h(APP_NAME) ?> - Admin Users</title>
</head>
<body>
  <p><a href="<?= h(APP_BASE_URL) ?>/admin/dashboard.php">Admin Dashboard</a> | <a href="<?= h(APP_BASE_URL) ?>/logout.php">Logout</a></p>

  <?php if ($flash): ?>
    <p><b><?= h((string)$flash['type']) ?>:</b> <?= h((string)$flash['message']) ?></p>
  <?php endif; ?>

  <h1>Users</h1>
  <p>Ban options: 7 days or lifetime. Unban removes ban.</p>

  <table border="1" cellpadding="6" cellspacing="0">
    <thead>
      <tr>
        <th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Verified</th><th>Ban</th><th>Until</th><th>Reason</th><th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($users as $u): ?>
      <tr>
        <td><?= (int)$u['id'] ?></td>
        <td><?= h((string)$u['full_name']) ?></td>
        <td><?= h((string)$u['email']) ?></td>
        <td><?= h((string)$u['role']) ?></td>
        <td><?= ((int)$u['is_verified']===1) ? 'Yes' : 'No' ?></td>
        <td><?= h((string)($u['ban_type'] ?? 'none')) ?></td>
        <td><?= h((string)($u['ban_until'] ?? '')) ?></td>
        <td><?= h((string)($u['ban_reason'] ?? '')) ?></td>
        <td>
          <form method="post" action="<?= h(APP_BASE_URL) ?>/admin/actions.php" style="display:inline;">
            <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
            <input type="hidden" name="action" value="ban_temp">
            <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
            <input type="hidden" name="days" value="7">
            <input type="hidden" name="reason" value="Admin temp ban (7 days)">
            <button type="submit">Ban 7d</button>
          </form>

          <form method="post" action="<?= h(APP_BASE_URL) ?>/admin/actions.php" style="display:inline;">
            <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
            <input type="hidden" name="action" value="ban_perm">
            <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
            <input type="hidden" name="reason" value="Admin permanent ban">
            <button type="submit">Ban Life</button>
          </form>

          <form method="post" action="<?= h(APP_BASE_URL) ?>/admin/actions.php" style="display:inline;">
            <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
            <input type="hidden" name="action" value="unban">
            <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
            <button type="submit">Unban</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</body>
</html>
