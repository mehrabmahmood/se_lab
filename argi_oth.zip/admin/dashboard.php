<?php

declare(strict_types=1);

require_once __DIR__ . '/../functions.php';
require_admin();

// quick counts
$open_reports = (int)db()->query("SELECT COUNT(*) FROM reports WHERE status='open'")->fetchColumn();
$user_count   = (int)db()->query("SELECT COUNT(*) FROM users")->fetchColumn();

$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h(APP_NAME) ?> - Admin Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-50 p-6">
  <div class="max-w-5xl mx-auto">
    <div class="flex items-center justify-between gap-3 flex-wrap">
      <div>
        <h1 class="text-2xl font-bold">Admin Dashboard</h1>
        <p class="text-sm text-gray-600">Moderation: reports, bans (1 week / lifetime), user management.</p>
      </div>
      <div class="flex gap-2 flex-wrap">
        <a class="px-3 py-2 rounded-lg bg-white shadow text-sm" href="<?= h(APP_BASE_URL) ?>/logout.php">Logout</a>
      </div>
    </div>

    <?php if ($flash): ?>
      <div class="mt-4 p-3 rounded <?= $flash['type']==='error' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700' ?>">
        <?= h((string)$flash['message']) ?>
      </div>
    <?php endif; ?>

    <div class="mt-6 grid md:grid-cols-3 gap-4">
      <a href="<?= h(APP_BASE_URL) ?>/admin/reports.php" class="bg-white rounded-2xl shadow p-6 hover:shadow-md transition block">
        <div class="text-sm text-gray-500">Open reports</div>
        <div class="text-3xl font-bold mt-1"><?= (int)$open_reports ?></div>
        <div class="text-sm text-gray-600 mt-2">Review malicious posts/comments, ban users.</div>
      </a>

      <a href="<?= h(APP_BASE_URL) ?>/admin/users.php" class="bg-white rounded-2xl shadow p-6 hover:shadow-md transition block">
        <div class="text-sm text-gray-500">Total users</div>
        <div class="text-3xl font-bold mt-1"><?= (int)$user_count ?></div>
        <div class="text-sm text-gray-600 mt-2">Ban/unban users, see roles.</div>
      </a>

      <a href="<?= h(APP_BASE_URL) ?>/admin/previous_product_sells.php" class="bg-white rounded-2xl shadow p-6 hover:shadow-md transition block">
        <div class="text-sm text-gray-500">Cache demo</div>
        <div class="text-2xl font-bold mt-1">Previous Product Sells</div>
        <div class="text-sm text-gray-600 mt-2">3 modes: secure cache vs unsecure cache vs no cache (TTL 30s).</div>
      </a>
    </div>

    <div class="mt-8 bg-white rounded-2xl shadow p-6">
      <h2 class="text-lg font-bold">Admin account</h2>
      <p class="text-sm text-gray-600 mt-2">Login with <span class="font-mono"><?= h(ADMIN_EMAIL) ?> / <?= h(ADMIN_PASSWORD) ?></span></p>
      <p class="text-xs text-gray-500 mt-2">Tip: In production, move admin to DB and use strong password.</p>
    </div>

  </div>
</body>
</html>
