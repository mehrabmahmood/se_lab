This folder is intentionally PUBLIC for the "Unsecure Caching" demo.

The cache demo writes JSON files here so they can be opened directly in the browser.
This demonstrates why public caching is unsafe (anyone can read/modify cached data).
