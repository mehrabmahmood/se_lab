<?php
echo shell_exec("where python");
?>
