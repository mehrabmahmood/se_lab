<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'member') {
  header("Location: login.php");
  exit();
}
require 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Member Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      font-family: 'Inter', sans-serif;
      margin: 0;
      background-color: #fff5f0;
    }
    .sidebar {
      width: 240px;
      height: 100vh;
      background: #efe7dd;
      position: fixed;
      left: 0;
      top: 0;
      padding: 40px 20px;
      box-shadow: 2px 0 10px rgba(0,0,0,0.05);
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }
    .project-name {
      font-size: 20px;
      font-weight: bold;
      color: #333;
      margin-bottom: 40px;
    }
    .user-info {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 30px;
      color: #000;
    }
    .user-info span {
      display: block;
      font-size: 14px;
      font-weight: 400;
      color: #666;
    }
    .sidebar ul {
      list-style: none;
      padding: 0;
      width: 100%;
    }
    .sidebar ul li {
      margin-bottom: 20px;
      font-weight: 500;
      color: #333;
      cursor: pointer;
    }
    .sidebar ul li a {
      text-decoration: none;
      color: #333;
      display: block;
      width: 100%;
    }
    .main {
      margin-left: 260px;
      padding: 40px;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 40px;
    }
    .header h1 {
      font-size: 28px;
    }
    .card {
      background: white;
      border-radius: 16px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      margin-bottom: 30px;
    }
    .card h3 {
      margin-bottom: 10px;
    }
    .card img {
      max-width: 150px;
      border-radius: 10px;
    }
    .button {
      padding: 10px 15px;

      background:rgb(150, 129, 104);
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .logout {
      color: red;
      text-decoration: none;
    }
    .map {
      height: 300px;
      width: 100%;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  
  <div class="sidebar">
    <div class="flex items-center space-x-2">
      <img src="./planting.png" alt="AGRI Logo" class="w-10 h-10" />
      <span class="text-xl font-bold text-orange-500">AGRI</span>
    </div>
    <div class="user-info px-2">
  Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>
</div>

    <ul>
     <li>
  <a href="member_dashboard.php"
     class="hover:px-6 py-3 text-gray-600 text-sm font-medium rounded-xl 
            bg-gray-100 
            pl-4
            hover:shadow-[4px_4px_10px_#d1d9e6,-4px_-4px_10px_#ffffff] 
            transition-all duration-300">
    Dashboard
  </a>
</li>

<li>
  <a href="index.html"
     class="hover:px-6 py-3 text-gray-600 text-sm font-medium rounded-xl 
            bg-gray-100 
            pl-4
            hover:shadow-[4px_4px_10px_#d1d9e6,-4px_-4px_10px_#ffffff] 
            transition-all duration-300">
    Home
  </a>
</li>

<li>
  <a href="logout.php"
     class="hover:px-6 py-3 text-gray-600 text-sm font-medium rounded-xl pl-4 
            bg-gray-100 
            hover:shadow-[4px_4px_10px_#d1d9e6,-4px_-4px_10px_#ffffff] 
            transition-all duration-300">
    Logout
  </a>
</li>

    </ul>
  </div>
  <div class="main">
    <div class="header">
      <h1>Member Dashboard</h1>
    </div>

    <div class="card">
      <h3>🌾🆘 Report for a help unknow crop disease </h3>
      <form action="submit_report.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
        <input type="hidden" name="latitude" id="latitude">
        <input type="hidden" name="longitude" id="longitude">
        <label for="description" class="block text-gray-700 font-medium mb-2">Description</label>
<textarea 
  name="description" 
  id="description" 
  placeholder="Describe the condition or location" 
  required 
  class="w-full px-4 py-3 text-sm text-gray-800 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-orange-400 transition duration-300 resize-none"
  rows="4"
></textarea>

        <label for="photoInput" class="block text-gray-700 font-medium mb-2">Upload a Photo</label>
<div class="relative w-full">
  <input 
    type="file" 
    name="photo" 
    id="photoInput" 
    accept="image/*" 
    required
    class="block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4
           file:rounded-full file:border-0
           file:text-sm file:font-semibold
           file:bg-orange-100 file:text-orange-700
           hover:file:bg-orange-200
           cursor-pointer transition duration-300"
  />
</div>

        <img id="photoPreview" style="display:none; max-width:200px; margin-top:10px;" />
        <div class="map" id="map"></div><br>
        <button type="submit" class="button bg-orange-200 text-orange-700" >Submit Report</button>
      </form>
    </div>

   <div class="card">
  <h3 class="text-xl font-semibold mb-4 text-gray-800">📝 Your Past Reports</h3>

  <?php
  $user_id = $_SESSION['user_id'];
  $result = $conn->query("SELECT * FROM reports WHERE user_id = $user_id ORDER BY created_at DESC");

  if ($result->num_rows === 0) {
    echo "<p class='text-gray-600'>You haven't submitted any reports yet.</p>";
  } else {
    while ($row = $result->fetch_assoc()):
  ?>
    <div class="mb-4 p-4 border border-gray-200 rounded-lg shadow-sm bg-white hover:shadow-md transition duration-300">
      <p class="mb-2 text-gray-700"><strong>Description:</strong> <?= htmlspecialchars($row['description']) ?></p>
      <p class="mb-2 text-gray-600 text-sm"><strong>📍 Location:</strong> (<?= $row['latitude'] ?>, <?= $row['longitude'] ?>)</p>

      <?php if ($row['photo_path']): ?>
        <div class="mb-3">
          <img src="<?= $row['photo_path'] ?>" alt="Reported Image" class="max-w-xs rounded-md border border-gray-300 shadow-sm">
        </div>
      <?php endif; ?>

      <p class="text-sm text-gray-500 italic">🕒 Submitted at: <?= date("M d, Y h:i A", strtotime($row['created_at'])) ?></p>

      <p class="mt-2">
        <span class="font-semibold text-gray-700">Status:</span>
        <span class="inline-block px-2 py-1 text-sm rounded 
          <?php
            echo ($row['status'] === 'saved') 
              ? 'bg-green-100 text-green-700' 
              : (($row['status'] === 'pending') 
                ? 'bg-red-100 text-red-700' 
                : 'bg-gray-100 text-gray-700');
          ?>">
          <?= htmlspecialchars(ucfirst($row['status'])) ?>
        </span>
      </p>
    </div>
  <?php endwhile; } ?>
</div>


  </div>

  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoviL0XngK8i6h2YLD7xOS5DFOG84m2dw&callback=initMap" async defer></script>
  <script>
    let map, marker;
    function initMap() {
      const defaultLoc = { lat: 23.8103, lng: 90.4125 };
      map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: defaultLoc
      });
      map.addListener("click", function(e) {
        placeMarker(e.latLng);
      });
    }
    function placeMarker(location) {
      if (marker) {
        marker.setPosition(location);
      } else {
        marker = new google.maps.Marker({
          position: location,
          map: map
        });
      }
      document.getElementById("latitude").value = location.lat();
      document.getElementById("longitude").value = location.lng();
    }
    document.getElementById('photoInput').addEventListener('change', function() {
      const file = this.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
          document.getElementById('photoPreview').src = e.target.result;
          document.getElementById('photoPreview').style.display = 'block';
        }
        reader.readAsDataURL(file);
      }
    });
    function validateForm() {
      if (!document.getElementById("latitude").value || !document.getElementById("longitude").value) {
        alert("Please select a location on the map.");
        return false;
      }
      return true;
    }
  </script>
</body>
</html>
