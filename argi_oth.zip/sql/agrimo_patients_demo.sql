-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2026 at 09:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agrimo_patients_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `previous_patients`
--

CREATE TABLE `previous_patients` (
  `id` int(10) UNSIGNED NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `animal_type` varchar(80) NOT NULL,
  `complaint` varchar(255) NOT NULL,
  `diagnosis` varchar(255) NOT NULL,
  `treatment` varchar(255) NOT NULL,
  `farmer_name` varchar(255) NOT NULL,
  `visited_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `previous_patients`
--

INSERT INTO `previous_patients` (`id`, `patient_name`, `animal_type`, `complaint`, `diagnosis`, `treatment`, `farmer_name`, `visited_at`) VALUES
(1, 'Ramu', 'Cow', 'Loss of appetite', 'Indigestion', 'Oral electrolyte + probiotics', 'Abdul Karim', '2026-01-25 18:18:53'),
(2, 'Mina', 'Goat', 'Coughing and nasal discharge', 'Respiratory infection', 'Antibiotic course (vet prescribed)', 'Rahima Begum', '2026-01-23 18:18:53'),
(3, 'Kalo', 'Dog', 'Skin itching and hair loss', 'Mange (suspected)', 'Topical antiparasitic + medicated bath', 'Sajid Hossain', '2026-01-21 18:18:53'),
(4, 'Sona', 'Chicken', 'Low egg production', 'Nutritional deficiency', 'Vitamin/mineral supplementation', 'Nazmul Islam', '2026-01-19 18:18:53'),
(5, 'Tuli', 'Cat', 'Vomiting', 'Gastritis', 'Diet change + antiemetic (vet prescribed)', 'Faria Ahmed', '2026-01-16 18:18:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `previous_patients`
--
ALTER TABLE `previous_patients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visited_at` (`visited_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `previous_patients`
--
ALTER TABLE `previous_patients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
