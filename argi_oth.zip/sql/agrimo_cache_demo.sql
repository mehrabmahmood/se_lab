-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2026 at 09:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agrimo_cache_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `previous_product_sells`
--

CREATE TABLE `previous_product_sells` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `sold_at` datetime NOT NULL,
  `buyer_name` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `previous_product_sells`
--

INSERT INTO `previous_product_sells` (`id`, `product_name`, `quantity`, `unit_price`, `sold_at`, `buyer_name`, `notes`) VALUES
(1, 'Tomato', 12, 35.00, '2026-01-25 22:39:24', 'Rahim', 'Delivered to local market'),
(2, 'Potato', 50, 18.50, '2026-01-24 22:39:24', 'Karim', 'Wholesale'),
(3, 'Rice', 5, 1200.00, '2026-01-23 22:39:24', 'Shop Owner', 'Premium quality');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `previous_product_sells`
--
ALTER TABLE `previous_product_sells`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sold_at` (`sold_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `previous_product_sells`
--
ALTER TABLE `previous_product_sells`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
